"""Image engine with automatic failover across several free servers (no API keys needed).

Order is set by IMAGE_PROVIDERS in .env. If one server is busy, slow or down, the next one is tried,
and a failing server is skipped for 60 seconds so users don't wait on it again.
"""
import asyncio, base64, io, os, threading, time
from urllib.parse import quote
import httpx
from starlette.concurrency import run_in_threadpool

HF_MODEL = os.getenv("HF_MODEL", "black-forest-labs/FLUX.1-schnell")
LOCAL_MODEL = os.getenv("LOCAL_MODEL", "stabilityai/sdxl-turbo")
HORDE = "https://aihorde.net/api/v2"
COOLDOWN = 60
DEFAULT = "pollinations_flux,pollinations_turbo,horde"

_client = httpx.AsyncClient(timeout=60, headers={"User-Agent": "ImagenStudio/1.0"}, follow_redirects=True)
_gate = asyncio.Semaphore(2)  # free servers throttle anonymous callers; keep our own load polite
_pipe, _lock, _cool = None, threading.Lock(), {}


class EngineError(Exception):
    pass


def _build_chain():
    names = [n.strip() for n in os.getenv("IMAGE_PROVIDERS", DEFAULT).split(",") if n.strip()]
    legacy = os.getenv("IMAGE_PROVIDER", "")
    if legacy in ("local", "huggingface") and legacy not in names:
        names.insert(0, legacy)
    if os.getenv("HF_TOKEN") and "huggingface" not in names:
        names.append("huggingface")  # optional extra, only if you happen to have a token
    if "huggingface" in names and not os.getenv("HF_TOKEN"):
        names.remove("huggingface")
    if "local" in names:
        import importlib.util
        if importlib.util.find_spec("diffusers") is None:
            names.remove("local")
    return [n for n in names if n in PROVIDERS] or DEFAULT.split(",")


def _valid(r):
    if r.status_code == 200 and r.headers.get("content-type", "").startswith("image/") and len(r.content) > 1000:
        return r.content
    raise EngineError(f"bad response {r.status_code}")


def _pollinations(model):
    async def run(prompt, w, h):
        params = {"width": w, "height": h, "model": model, "nologo": "true", "private": "true",
                  "seed": int.from_bytes(os.urandom(3), "big")}
        if os.getenv("POLLINATIONS_KEY"):
            params["key"] = os.environ["POLLINATIONS_KEY"]
        async with _gate:
            return _valid(await _client.get(f"https://image.pollinations.ai/prompt/{quote(prompt, safe='')}", params=params))
    return run


async def _horde(prompt, w, h):
    hdr = {"apikey": os.getenv("HORDE_KEY", "0000000000"), "Client-Agent": "ImagenStudio:1.0:self-hosted"}
    s = min(1.0, 576 / max(w, h))  # anonymous users are limited to small images
    W, H = max(64, round(w * s / 64) * 64), max(64, round(h * s / 64) * 64)
    r = await _client.post(f"{HORDE}/generate/async", headers=hdr, json={
        "prompt": prompt, "nsfw": False, "censor_nsfw": True, "r2": True, "slow_workers": True,
        "params": {"width": W, "height": H, "steps": 20, "n": 1, "cfg_scale": 7}})
    if r.status_code not in (200, 202):
        raise EngineError(f"horde {r.status_code}")
    job, done = r.json()["id"], False
    try:
        for _ in range(70):
            await asyncio.sleep(2)
            st = (await _client.get(f"{HORDE}/generate/status/{job}", headers=hdr)).json()
            if st.get("faulted"):
                raise EngineError("horde faulted")
            if st.get("done") and st.get("generations"):
                img = st["generations"][0]["img"]
                done = True
                if img.startswith("http"):
                    g = await _client.get(img)
                    g.raise_for_status()
                    return g.content
                return base64.b64decode(img)
        raise EngineError("horde timeout")
    finally:
        if not done:  # free the community GPU if we gave up
            asyncio.create_task(_client.delete(f"{HORDE}/generate/status/{job}", headers=hdr))


async def _hf(prompt, w, h):
    r = await _client.post(
        f"https://router.huggingface.co/hf-inference/models/{HF_MODEL}",
        headers={"Authorization": f"Bearer {os.environ['HF_TOKEN']}"},
        json={"inputs": prompt, "parameters": {"width": w, "height": h}})
    return _valid(r)


async def _local_async(prompt, w, h):
    return await run_in_threadpool(_local, prompt, w, h)


def _local(prompt, w, h) -> bytes:
    global _pipe
    with _lock:
        if _pipe is None:
            import torch
            from diffusers import AutoPipelineForText2Image
            cuda = torch.cuda.is_available()
            _pipe = AutoPipelineForText2Image.from_pretrained(
                LOCAL_MODEL, torch_dtype=torch.float16 if cuda else torch.float32).to("cuda" if cuda else "cpu")
        img = _pipe(prompt, width=w, height=h, num_inference_steps=2, guidance_scale=0.0).images[0]
        buf = io.BytesIO()
        img.save(buf, "PNG")
        return buf.getvalue()


PROVIDERS = {  # name -> (function, timeout seconds)
    "pollinations_flux": (_pollinations("flux"), 50),
    "pollinations_turbo": (_pollinations("turbo"), 40),
    "horde": (_horde, 150),
    "huggingface": (_hf, 60),
    "local": (_local_async, 300),
}
CHAIN = _build_chain()


async def generate_image(prompt: str, width: int, height: int) -> bytes:
    now = time.time()
    order = [n for n in CHAIN if _cool.get(n, 0) < now] or CHAIN  # skip recently failed servers
    for name in order:
        fn, timeout = PROVIDERS[name]
        try:
            data = await asyncio.wait_for(fn(prompt, width, height), timeout)
            _cool.pop(name, None)
            return data
        except Exception:
            _cool[name] = time.time() + COOLDOWN
    raise EngineError("All free image servers are busy right now. Please try again in a minute.")
