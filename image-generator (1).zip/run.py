"""One-command launcher that checks everything, then starts the app.

    python run.py            check, self-test, then start the server
    python run.py --check    only check and self-test
    python run.py --host 0.0.0.0 --port 8000
"""
import argparse, importlib.util, os, secrets, socket, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).parent.resolve()
os.chdir(ROOT)
OK, BAD, WARN = "[ ok ]", "[FAIL]", "[warn]"
REQUIRED = {"fastapi": "fastapi", "uvicorn": "uvicorn", "sqlalchemy": "sqlalchemy", "bcrypt": "bcrypt",
            "jwt": "PyJWT", "httpx": "httpx", "slowapi": "slowapi", "pydantic": "pydantic"}


def step(tag, msg):
    print(f"{tag} {msg}")


def load_env():
    f = ROOT / ".env"
    if not f.exists():
        text = (ROOT / ".env.example").read_text() if (ROOT / ".env.example").exists() else ""
        text = text.replace("change-me-to-a-long-random-string", secrets.token_urlsafe(48))
        f.write_text(text or f"SECRET_KEY={secrets.token_urlsafe(48)}\nCOOKIE_SECURE=false\n")
        step(OK, "Created .env with a new random SECRET_KEY")
    for line in f.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"'))


def check_python():
    if sys.version_info < (3, 9):
        step(BAD, f"Python 3.9+ required, found {sys.version.split()[0]}"); sys.exit(1)
    step(OK, f"Python {sys.version.split()[0]}")


def check_packages():
    missing = [pip for mod, pip in REQUIRED.items() if importlib.util.find_spec(mod) is None]
    if missing:
        step(WARN, f"Missing packages: {', '.join(missing)}. Installing from requirements.txt...")
        r = subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        if r.returncode != 0:
            step(BAD, "Install failed. Check your internet connection and run: pip install -r requirements.txt"); sys.exit(1)
    step(OK, "All required packages are installed")


def check_config():
    if len(os.environ.get("SECRET_KEY", "")) < 32:
        step(BAD, "SECRET_KEY in .env must be 32+ characters. Delete .env to generate a new one."); sys.exit(1)
    step(OK, "SECRET_KEY is set")
    import engine
    step(OK, "Free image servers, tried in order with automatic failover: " + ", ".join(engine.CHAIN))
    if not (ROOT / "index.html").exists():
        step(BAD, "index.html is missing. Keep it next to run.py."); sys.exit(1)


SELFTEST = r'''
import sys
from fastapi.testclient import TestClient
import main
c = TestClient(main.app)
fails = []
def check(name, cond):
    print(("  pass " if cond else "  FAIL ") + name)
    if not cond: fails.append(name)
check("home page loads", c.get("/").status_code == 200)
check("health check", c.get("/healthz").status_code == 200)
check("blocked when signed out", c.get("/api/me").status_code == 401 and c.post("/api/generate", json={"prompt": "a cat"}).status_code == 401)
creds = {"email": "check@example.com", "password": "Passw0rd-test"}
check("register", c.post("/api/auth/register", json=creds).status_code == 201)
check("session works", c.get("/api/me").json().get("email") == creds["email"])
check("duplicate email rejected", c.post("/api/auth/register", json=creds).status_code == 409)
check("short password rejected", c.post("/api/auth/register", json={"email": "x@y.co", "password": "123"}).status_code == 422)
c.post("/api/auth/logout")
check("logout works", c.get("/api/me").status_code == 401)
check("wrong password rejected", c.post("/api/auth/login", json={**creds, "password": "wrong-password"}).status_code == 401)
check("login", c.post("/api/auth/login", json=creds).status_code == 200)
check("gallery starts empty", c.get("/api/images").json() == [])
check("other users' images hidden", c.get("/api/images/doesnotexist/file").status_code == 404)
sys.exit(1 if fails else 0)
'''


def self_test():
    print("Running self-test (temporary database, no image credits used)...")
    env = {**os.environ, "DATA_DIR": tempfile.mkdtemp(), "COOKIE_SECURE": "false"}
    r = subprocess.run([sys.executable, "-c", SELFTEST], env=env, cwd=ROOT)
    if r.returncode != 0:
        step(BAD, "Self-test failed. See the lines marked FAIL above."); sys.exit(1)
    step(OK, "Self-test passed: sign-up, sign-in, sign-out and access checks all work")


def free_port(host, port):
    for p in range(port, port + 20):
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    step(BAD, f"No free port found from {port} to {port + 19}."); sys.exit(1)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    a = ap.parse_args()
    check_python(); load_env(); check_packages(); check_config(); self_test()
    if a.check:
        step(OK, "Everything is ready. Start the app with: python run.py"); sys.exit(0)
    port = free_port(a.host, a.port)
    step(OK, f"Starting at http://{'localhost' if a.host == '127.0.0.1' else a.host}:{port}  (Ctrl+C to stop)")
    import uvicorn
    uvicorn.run("main:app", host=a.host, port=port)
