import os, re, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

import bcrypt, jwt
from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address
from sqlalchemy import DateTime, ForeignKey, String, create_engine, func, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from engine import EngineError, generate_image

SECRET_KEY = os.environ.get("SECRET_KEY", "")
if len(SECRET_KEY) < 32:
    raise RuntimeError("Set SECRET_KEY to a random string of 32+ characters.")
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "true").lower() == "true"
DAILY_LIMIT = int(os.getenv("DAILY_LIMIT", "30"))
DATA_DIR = Path(os.getenv("DATA_DIR", "./data"))
IMG_DIR = DATA_DIR / "images"
IMG_DIR.mkdir(parents=True, exist_ok=True)
TOKEN_HOURS = 12

# ---------- database ----------
engine = create_engine(f"sqlite:///{DATA_DIR / 'app.db'}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(engine, expire_on_commit=False)
now = lambda: datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(254), unique=True, index=True)
    password_hash: Mapped[bytes]
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)


class Image(Base):
    __tablename__ = "images"
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    prompt: Mapped[str] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)


Base.metadata.create_all(engine)


def db():
    with SessionLocal() as s:
        yield s


# ---------- auth ----------
def make_token(uid: int) -> str:
    return jwt.encode({"sub": str(uid), "exp": now() + timedelta(hours=TOKEN_HOURS)}, SECRET_KEY, "HS256")


def current_user(request: Request, s: Session = Depends(db)) -> User:
    token = request.cookies.get("session")
    try:
        uid = int(jwt.decode(token or "", SECRET_KEY, ["HS256"])["sub"])
    except (jwt.PyJWTError, ValueError):
        raise HTTPException(401, "Please sign in.")
    user = s.get(User, uid)
    if not user:
        raise HTTPException(401, "Please sign in.")
    return user


EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class Credentials(BaseModel):
    email: str = Field(max_length=254)
    password: str = Field(min_length=8, max_length=128)

    @field_validator("email")
    @classmethod
    def valid_email(cls, v):
        v = v.strip().lower()
        if not EMAIL.match(v):
            raise ValueError("Enter a valid email address.")
        return v


class GenerateIn(BaseModel):
    prompt: str = Field(min_length=3, max_length=500)
    size: str = Field(default="1024x1024", pattern=r"^(1024x1024|1344x768|768x1344)$")


# ---------- app ----------
limiter = Limiter(key_func=get_remote_address)
app = FastAPI(title="Imagen Studio", docs_url=None, redoc_url=None)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    r = await call_next(request)
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["X-Frame-Options"] = "DENY"
    r.headers["Referrer-Policy"] = "same-origin"
    r.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'"
    )
    return r


def set_session(resp: Response, uid: int):
    resp.set_cookie("session", make_token(uid), max_age=TOKEN_HOURS * 3600, httponly=True,
                    secure=COOKIE_SECURE, samesite="lax", path="/")


@app.get("/healthz")
def health():
    return {"ok": True}


@app.post("/api/auth/register", status_code=201)
@limiter.limit("5/minute")
def register(request: Request, body: Credentials, response: Response, s: Session = Depends(db)):
    if s.scalar(select(User).where(User.email == body.email)):
        raise HTTPException(409, "An account with this email already exists.")
    pw = bcrypt.hashpw(body.password.encode(), bcrypt.gensalt(12))
    user = User(email=body.email, password_hash=pw)
    s.add(user); s.commit()
    set_session(response, user.id)
    return {"email": user.email}


@app.post("/api/auth/login")
@limiter.limit("10/minute")
def login(request: Request, body: Credentials, response: Response, s: Session = Depends(db)):
    user = s.scalar(select(User).where(User.email == body.email))
    # Same error for unknown email and wrong password: no account enumeration.
    if not user or not bcrypt.checkpw(body.password.encode(), user.password_hash):
        raise HTTPException(401, "Email or password is incorrect.")
    set_session(response, user.id)
    return {"email": user.email}


@app.post("/api/auth/logout")
def logout(response: Response):
    response.delete_cookie("session", path="/")
    return {"ok": True}


@app.get("/api/me")
def me(user: User = Depends(current_user)):
    return {"email": user.email}


@app.post("/api/generate")
@limiter.limit("12/minute")
async def generate(request: Request, body: GenerateIn, user: User = Depends(current_user), s: Session = Depends(db)):
    since = now().replace(hour=0, minute=0, second=0, microsecond=0)
    used = s.scalar(select(func.count()).select_from(Image).where(Image.user_id == user.id, Image.created_at >= since))
    if used >= DAILY_LIMIT:
        raise HTTPException(429, f"Daily limit of {DAILY_LIMIT} images reached. Try again tomorrow.")
    w, h = map(int, body.size.split("x"))
    try:
        data = await generate_image(body.prompt.strip(), w, h)
    except EngineError as e:
        raise HTTPException(502, str(e))
    except Exception:
        raise HTTPException(502, "Image generation failed. Please try again.")
    img = Image(id=uuid.uuid4().hex, user_id=user.id, prompt=body.prompt.strip())
    (IMG_DIR / f"{img.id}.png").write_bytes(data)
    s.add(img); s.commit()
    return {"id": img.id, "prompt": img.prompt, "remaining": DAILY_LIMIT - used - 1}


@app.get("/api/images")
def list_images(user: User = Depends(current_user), s: Session = Depends(db)):
    rows = s.scalars(select(Image).where(Image.user_id == user.id).order_by(Image.created_at.desc()).limit(60))
    return [{"id": i.id, "prompt": i.prompt} for i in rows]


def owned(image_id: str, user: User, s: Session) -> Image:
    img = s.get(Image, image_id)
    if not img or img.user_id != user.id:  # users can only touch their own images
        raise HTTPException(404, "Image not found.")
    return img


@app.get("/api/images/{image_id}/file")
def image_file(image_id: str, user: User = Depends(current_user), s: Session = Depends(db)):
    owned(image_id, user, s)
    path = IMG_DIR / f"{image_id}.png"
    with open(path, "rb") as f:
        head = f.read(4)
    mime = "image/jpeg" if head[:2] == b"\xff\xd8" else "image/webp" if head == b"RIFF" else "image/png"
    return FileResponse(path, media_type=mime,
                        headers={"Cache-Control": "private, max-age=86400"})


@app.delete("/api/images/{image_id}")
def delete_image(image_id: str, user: User = Depends(current_user), s: Session = Depends(db)):
    img = owned(image_id, user, s)
    (IMG_DIR / f"{img.id}.png").unlink(missing_ok=True)
    s.delete(img); s.commit()
    return {"ok": True}


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(Path(__file__).parent / "index.html", headers={"Cache-Control": "no-cache"})
